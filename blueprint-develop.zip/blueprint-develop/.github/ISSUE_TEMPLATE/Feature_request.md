---
name: ⭐️ Feature request
about: Propose a new feature or suggest an idea
---

<!-- IF YOU ARE A PALANTIR EMPLOYEE, DO NOT POST INTERNAL LINKS OR REFERENCES HERE -->

#### Environment

- __Package version(s)__: <!-- fill this out -->
- __Browser and OS versions__: <!-- fill this out -->

#### Feature request

<!-- fill this out -->

#### Examples

<!-- fill this out -->
