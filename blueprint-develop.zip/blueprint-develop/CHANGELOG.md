Changelog
---------

Changelogs for `@blueprintjs/*` packages currently live in the project's Github wiki:

- [4.x Changelog](https://github.com/palantir/blueprint/wiki/4.x-Changelog)
- [3.x Changelog](https://github.com/palantir/blueprint/wiki/3.x-Changelog)
