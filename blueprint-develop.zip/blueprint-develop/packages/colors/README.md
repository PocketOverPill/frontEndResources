<img height="204" src="https://cloud.githubusercontent.com/assets/464822/20228152/d3f36dc2-a804-11e6-80ff-51ada2d13ea7.png">

# [Blueprint](http://blueprintjs.com/) Colors

Blueprint is a React UI toolkit for the web.

This package contains color variables for Blueprint's color palette.

There are currently two color palettes available: modern 4.x colors and "legacy" 3.x colors.

## Installation

```
npm install --save @blueprintjs/colors
```

### [Full Documentation](http://blueprintjs.com/docs) | [Source Code](https://github.com/palantir/blueprint)
