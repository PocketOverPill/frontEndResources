/*
 * Copyright 2022 Palantir Technologies, Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { expect } from "chai";

import { Months } from "@blueprintjs/datetime";

import { isDayInRange, isSameTime } from "../../src/common/dateUtils";

describe("DateUtils", () => {
    it("isSameTime", () => {
        const d1 = new Date(2022, Months.JULY, 8);
        const d2 = new Date(2022, Months.JULY, 8);
        const d3 = new Date(2022, Months.JULY, 9);
        expect(isSameTime(d1, d2), "same day, same time").to.be.true;
        expect(isSameTime(d1, d3), "different day, same time").to.be.true;
    });

    it("isDayInRange", () => {
        const d1 = new Date(2022, Months.JULY, 7);
        const d2 = new Date(2022, Months.JULY, 8);
        const d3 = new Date(2022, Months.JULY, 9);
        expect(isDayInRange(d2, [d1, d3])).to.be.true;
    });
});
