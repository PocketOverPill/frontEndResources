/*
 * (c) Copyright 2022 Palantir Technologies Inc. All rights reserved.
 */

declare module "*.scss" {
    const styles: any;
    export = styles;
}
