# [Blueprint Documentation](http://blueprintjs.com/docs)

This project generates and aggregates the documentation from the packages
in this repo.

## Quick start

From the root of the repo:

1. Run `yarn`
1. Run `yarn dev`
1. Open your browser to http://localhost:9000/

*Note: if you want to run the development server on a different port, set the `PORT` environment variable.*
