<!--
This file enumerates the exact order of root pages in the left sidebar.
-->

@page blueprint
@page core
@page datetime
@page datetime2
@page icons
@page select
@page table
@page timezone
@page popover2-package
@page resources
