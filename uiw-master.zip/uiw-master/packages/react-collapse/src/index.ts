import Collapse from './Collapse';

export * from './Collapse';
export * from './Panel';

export default Collapse;
